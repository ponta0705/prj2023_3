package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

public class SearchServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		String error = "";
		String cmd = "";

		try {
			dao.BookDAO objDao = new dao.BookDAO();

			bean.Book book = new bean.Book();

			//エンコードを設定
			response.setContentType("text/html; charset=UTF-8");

			//検索条件受け取る
			String isbn = request.getParameter("isbn");
			String title = request.getParameter("title");
			String price = request.getParameter("price");

			//BookDAOクラスに定義したsearch（）メソッドを利用して書籍情報を取得
			ArrayList<bean.Book> list = objDao.search(isbn, title, price);

			request.setAttribute("book_list", list);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
