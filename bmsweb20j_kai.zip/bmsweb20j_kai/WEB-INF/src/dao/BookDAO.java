/*
 * プログラム名：書籍管理アプリStep1
 * プログラムの説明：書籍情報の登録と閲覧。
 * 作成者：甲斐彩夏
 * 作成日：2023年5月31日
 */

package dao;

import java.sql.*;
import java.util.*;

public class BookDAO{

	/**
	 * JDBCドライバ内部のDriverクラスパス
	 */
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	/**
	 * 接続するMySQLデータベースパス
	 */
	private static final String URL = "jdbc:mysql://localhost/mybookdb";
	/**
	 * データベースのユーザー名
	 */
	private static final String USER = "root";
	/**
	 * データベースのパスワード
	 */
	private static final String PASSWD = "root123";

	/**
	 * フィールド変数の情報を基に、DB接続をおこなうメソッド
	 *
	 * @return データベース接続情報
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public static Connection getConnection()
	{
		try{
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		}catch(Exception e){
			throw new IllegalStateException(e);
		}
	}

	/**
	 * DBの書籍情報を格納するbookinfoテーブルから全書籍情報を取得するメソッド
	 *
	 * @return 全書籍情報のリスト
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public ArrayList<bean.Book> selectAll()	{

		ArrayList<bean.Book> list = new ArrayList<bean.Book>();
		String sql = "SELECT * FROM bookinfo ORDER BY ISBN";

		Connection con = null;
		Statement  smt = null;
		try{
			con = BookDAO.getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()){
				bean.Book books = new bean.Book();
				books.setIsbn(rs.getString("isbn"));
				books.setTitle(rs.getString("title"));
				books.setPrice(rs.getInt("price"));

				list.add(books);
			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return list;

	}

	//データベースに書籍データを登録するインスタンスメソッド
	public void insert(bean.Book book) {

		Connection con = null;
		Statement smt = null;

		try {
			String sql = "INSERT INTO bookinfo(isbn, title, price) VALUE ('" + book.getIsbn() + "','" + book.getTitle() + "'," + book.getPrice() + ")";

			con = BookDAO.getConnection();
			smt = con.createStatement();

			int rowsCount = smt.executeUpdate(sql);

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	//指定された書籍データをデータベースから検索し、Bookオブジェクトに格納するインスタンスメソッド
	public bean.Book selectByIsbn(String isbn) {

		Connection con = null;
		Statement smt = null;

		bean.Book book = new bean.Book();

		try {

			//検索用SQL文
			String sql = "SELECT isbn,title,price FROM bookinfo WHERE isbn = '" + isbn + "'";

			con = BookDAO.getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			if(rs.next()) {
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));
			}
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return book;
	}

	public void delete(String isbn) {

		Connection con = null;
		Statement smt = null;

		try {

			String sql = "DELETE FROM bookinfo WHERE isbn = '"+ isbn +"'";

			con = getConnection();
			smt = con.createStatement();

			int rowCount = smt.executeUpdate(sql);

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	public void update(bean.Book book) {

		Connection con = null;
		Statement smt = null;

		try {

			String sql = "UPDATE bookinfo SET title='"+book.getTitle()+"',price="+book.getPrice()+" WHERE isbn='"+book.getIsbn()+"'";

			con = BookDAO.getConnection();
			smt = con.createStatement();

			int rowCount = smt.executeUpdate(sql);

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	public ArrayList<bean.Book> search(String isbn, String title, String price){

		Connection con = null;
		Statement smt = null;

		ArrayList<bean.Book> booklist = new ArrayList<bean.Book>();

		try {

			String sql = "SELECT isbn,title,price FROM bookinfo WHERE isbn LIKE '%" + isbn + "%' AND title LIKE '%" + title + "%' AND price LIKE '%" + price + "%'";

			con = BookDAO.getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				bean.Book books = new bean.Book();
				books.setIsbn(rs.getString("isbn"));
				books.setTitle(rs.getString("title"));
				books.setPrice(rs.getInt("price"));

				booklist.add(books);
			}
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}

		return booklist;
	}

}
