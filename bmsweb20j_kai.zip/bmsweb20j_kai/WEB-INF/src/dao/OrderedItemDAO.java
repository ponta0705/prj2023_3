package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import bean.OrderedItem;

public class OrderedItemDAO {

	//DB情報
	private static String RDB_DRIVE="com.mysql.jdbc.Driver";
	private static String URL="jdbc:mysql://localhost/mybookdb";
	private static String USER="root";
	private static String PASSWD="root123";

	//DB接続メソッド
		public static Connection getConnection() {
			try{
				Class.forName(RDB_DRIVE);
				Connection con = DriverManager.getConnection(URL, USER, PASSWD);
				return con;
			}catch(Exception e){
				throw new IllegalStateException(e);
			}
		}

		public ArrayList<OrderedItem> selectAll(){

			ArrayList<OrderedItem> ordereditem_list = new ArrayList<OrderedItem>();

			Connection con = null;
			Statement smt = null;

			OrderedItem ordereditem = new OrderedItem();

			try {

				String sql = "SELECT o.user,b.title,o.date FROM bookinfo b INNER JOIN orderinfo o ON b.isbn=o.isbn";

				con = UserDAO.getConnection();
				smt = con.createStatement();

				ResultSet rs = smt.executeQuery(sql);

				if(rs.next()) {
					ordereditem.setUserid(rs.getString("isbn"));
					ordereditem.setTitle(rs.getString("title"));
					ordereditem.setDate(rs.getString("price"));

					ordereditem_list.add(ordereditem);
				}
			}catch(Exception e){
				throw new IllegalStateException(e);
			}finally{
				if(smt != null){
					try{smt.close();}catch(SQLException ignore){}
				}
				if(con != null){
					try{con.close();}catch(SQLException ignore){}
				}
			}
			return ordereditem_list;
		}

}
