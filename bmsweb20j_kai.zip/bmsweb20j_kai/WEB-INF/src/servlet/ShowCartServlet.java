package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Order;
import bean.User;
import bean.Book;

import java.util.ArrayList;

public class ShowCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		HttpSession session = request.getSession();

		String error = "";
		String cmd= "";

		try {

			dao.BookDAO BookDaoObj = new dao.BookDAO();

			String delno = request.getParameter("delno");

			bean.User user = (bean.User)session.getAttribute("user");
			if(user == null) {
				error = "セッション切れの為、カート状況は確認出来ません。";
				cmd = "logout";
			}

			ArrayList<Book> book_list = new ArrayList<Book>();

			ArrayList<Order> order_list = (ArrayList<Order>)session.getAttribute("order_list");
			if(order_list != null) {
				if(delno != null) {
					order_list.remove(Integer.parseInt(delno));
				}


				for(int i = 0; i < order_list.size(); i++) {
					Book Book = BookDaoObj.selectByIsbn(order_list.get(i).getIsbn());
					book_list.add(Book);
				}

			}

			request.setAttribute("book_list", book_list);
		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、書籍削除処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error != "") {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("/view/showCart.jsp").forward(request, response);
			}
		}
	}
}
