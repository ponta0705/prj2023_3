package util;

import java.text.DecimalFormat;

public class MyFormat {

	public String moneyFormat(int price) {

		java.text.DecimalFormat obj = new DecimalFormat("\u00A5###,##0");

		return obj.format(price);
	}

}
