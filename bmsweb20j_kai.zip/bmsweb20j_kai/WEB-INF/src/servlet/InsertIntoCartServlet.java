package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Order;
import bean.User;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		HttpSession session = request.getSession();

		String error = "";
		String cmd = "";

		try{
			dao.BookDAO bookDaoObj = new dao.BookDAO();

		//セッションからユーザー情報を取得
			User user = (User)session.getAttribute("user");
		//セッション切れか確認
		if(user == null){
		//セッション切れならerror.jspへフォワード
			request.setAttribute("error","セッション切れの為、メニュー画面が表示できませんでした。");
			request.setAttribute("cmd","logout");
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			return;
		}

		//isbnのパラメータを取得
		String isbn = request.getParameter("isbn");

		//BookDAOをインスタンス化し、関連メソッドを呼び出す
		bean.Book book = bookDaoObj.selectByIsbn(isbn);

		//Bookオブジェクトをリクエストスコープに"Book"という名前で格納
		request.setAttribute("book", book);

		//isbn、userid(ログイン者)、数量(1固定)を設定
		bean.Order order = new bean.Order();
		order.setIsbn(isbn);
		order.setUserid(user.getUserid());
		order.setQuantity(1);


		ArrayList<Order> list = (ArrayList<Order>)session.getAttribute("order_list");
		if(list == null) {
			list = new ArrayList<Order>();
		}
		list.add(order);

		session.setAttribute("order_list",list);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、書籍削除処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error != "") {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("/view/InsertIntoCart.jsp").forward(request, response);
			}
		}
	}
}
