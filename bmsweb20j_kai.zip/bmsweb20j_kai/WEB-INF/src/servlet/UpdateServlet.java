package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

			String error = "";
			String cmd = "";

		try {

			dao.BookDAO objDao = new dao.BookDAO();

			bean.Book book = new bean.Book();

			//エンコードを設定
			response.setContentType("text/html; charset=UTF-8");

			//画面からの入力情報を受け取り、Bookオブジェクトに格納
			//ISBN
			String isbn = request.getParameter("isbn");
			book.setIsbn(isbn);

			//Title
			String checkTitle = request.getParameter("title");
			if(checkTitle.equals("")) {
				error = "タイトルが未入力の為、書籍管理登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
				book.setTitle(checkTitle);


			//Price
			String checkPrice = request.getParameter("price");
			if(checkPrice.equals("")) {
				error = "価格が未入力の為、書籍管理登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
			book.setPrice(Integer.parseInt(checkPrice));

			//BookDAOクラスのメソッドを利用して書籍データを更新
			objDao.update(book);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";
		}catch(NumberFormatException e){
			error = "価格の値が不正の為、書籍登録処理は行えませんでした。";
			cmd = "list";
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/list").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
