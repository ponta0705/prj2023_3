package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.*;

import dao.OrderedItemDAO;
import bean.OrderedItem;

public class ShowOrderedItemServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		OrderedItemDAO orderedItemDao = new OrderedItemDAO();

		ArrayList<OrderedItem> list = orderedItemDao.selectAll();

		request.setAttribute("ordered_list", list);

		request.getRequestDispatcher("/view/showOrderedItem.jsp").forward(request, response);
	}

}
