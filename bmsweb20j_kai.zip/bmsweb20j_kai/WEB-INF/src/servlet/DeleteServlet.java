package servlet;

import java.io.*;
import java.util.Set;

import javax.servlet.*;
import javax.servlet.http.*;

public class DeleteServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		String error = "";
		String cmd = "";

		try {
			dao.BookDAO objDao = new dao.BookDAO();

			bean.Book book = new bean.Book();

			//エンコードを設定
			response.setContentType("text/html; charset=UTF-8");

			//isbnデータを取得
			String isbn = request.getParameter("isbn");

			//BookDAOクラスのメソッドを利用して書籍情報を取得
			book = objDao.selectByIsbn(isbn);
			if(book.getIsbn() == null) {
			error = "表示対象の書籍が存在しない為、詳細情報は表示できませんでした。";
			cmd = "list";
			return;
			}

			//deleteメソッドを呼び出す
			objDao.delete(isbn);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、書籍削除処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error != "") {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("/list").forward(request, response);
			}
		}


	}
}
