/*
 * プログラム名：書籍管理アプリStep5
 * プログラムの説明：書籍情報の登録と閲覧。
 * 作成者：甲斐彩夏
 * 作成日：2023年6月1日
 */

package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DetailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException,IOException{

		//cmdパラメータの取得
		String cmd = request.getParameter("cmd");
		String error = "";

		try {

			//BookDAOクラスのオブジェクト生成
			dao.BookDAO objDao = new dao.BookDAO();

			//Bookオブジェクト生成
			bean.Book book = new bean.Book();

			//エンコード設定
			request.setCharacterEncoding("UTF-8");

			//isbnパラメータの取得
			String isbn = request.getParameter("isbn");

			//BookDAOクラスのメソッドを利用して書籍情報を取得
			book = objDao.selectByIsbn(isbn);
			if(book.getIsbn() == null) {
				error = "表示対象の書籍が存在しない為、詳細情報は表示できませんでした。";
				cmd = "list";
				return;
			}

			//リクエストスコープ
			request.setAttribute("book", book);

		}catch(IllegalStateException e) {
			if(cmd.equals("detail")) {
				error = "DB接続エラーの為、書籍詳細は表示できませんでした。";
				cmd = "logout";
			}else if(cmd.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
				cmd = "logout";
			}
		}finally {

			if(error.equals("")) {
				if(cmd.equals("detail")) {
					request.getRequestDispatcher("/view/detail.jsp").forward(request, response);
				}else if(cmd.equals("update")) {
					request.getRequestDispatcher("/view/update.jsp").forward(request, response);
				}
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
