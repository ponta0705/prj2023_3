package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		String error = "";
		String cmd = "";

		HttpSession session = request.getSession();

		bean.User user = null;

		String userid1 = "";
		String password1 = "";

		try {

			//入力パラメータを取得する
			String userid = request.getParameter("userid");
			String password = request.getParameter("password");

			//UerDaoをインスタンス化
			dao.UserDAO userDaoObj = new dao.UserDAO();

			user = userDaoObj.selectByUser(userid, password);

			userid1 = user.getUserid();


		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、書籍削除処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error != "") {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
				if(userid1 != null) {
					session.setAttribute("user", user);

					//useridクッキー
					Cookie userCookie = new Cookie("userid", userid1);
					userCookie.setMaxAge(60*60*24*5);
					response.addCookie(userCookie);

					//passwordクッキー
					Cookie passwordCookie = new Cookie("password", password1);
					passwordCookie.setMaxAge(60*60*24*5);
					response.addCookie(userCookie);

					request.getRequestDispatcher("/view/menu.jsp").forward(request, response);

				}else {
					request.setAttribute("message", "入力データが間違っています!");
					request.getRequestDispatcher("/view/login.jsp").forward(request, response);
				}
			}
		}
	}

}
