package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Book;
import bean.Order;

import dao.BookDAO;
import dao.OrderDAO;

public class BuyConfirmServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		HttpSession session = request.getSession();

		String error = "";
		String cmd = "";

		try{
			bean.User user = (bean.User)session.getAttribute("user");
			if(user == null) {
				error = "セッション切れの為、購入は出来ません。";
				cmd = "logout";
			}

			ArrayList<Order> order_list = (ArrayList<Order>)session.getAttribute("order_list");
			if(order_list == null) {
				error = "カートの中に何も無かったので購入は出来ません。";
				cmd = "menu";
				}

			ArrayList<Book> book_list = new ArrayList<Book>();

			BookDAO bookDao = new BookDAO();
			OrderDAO orderDao = new OrderDAO();

			for(int i = 0; i < order_list.size(); i++) {
				Book Book = bookDao.selectByIsbn(order_list.get(i).getIsbn());
				book_list.add(Book);
			}

			request.setAttribute("book_list", book_list);
		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、書籍削除処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error != "") {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("/view/buyComfirm.jsp").forward(request, response);
			}
		}
	}
}
