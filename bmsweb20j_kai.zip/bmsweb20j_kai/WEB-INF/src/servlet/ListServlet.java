/*
 * プログラム名：書籍管理アプリStep3
 * プログラムの説明：書籍情報の登録と閲覧。
 * 作成者：甲斐彩夏
 * 作成日：2023年5月31日
 */

package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

public class ListServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request ,HttpServletResponse response)
	throws ServletException ,IOException{

		String error = "";
		String cmd = "";


		try {

			// ① BookDAOをインスタンス化する
			dao.BookDAO objDao = new dao.BookDAO();

			// ②関連メソッドを呼び出し、戻り値としてBookオブジェクトのリストを取得する
			ArrayList<bean.Book> list = objDao.selectAll();

			// ③②で取得したListをリクエストスコープに"book_list"という名前で格納する
			request.setAttribute("book_list", list);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";

		}finally {

			if(error.equals("")) {
				// ④list.jspにフォワード
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

		}

	}
}
